# TrOCR Fine-tuned on [Datasets Name] (Slavic Handwriting)

This model is a fine-tuned version of [`kazars24/trocr-base-handwritten-ru`](https://huggingface.co/kazars24/trocr-base-handwritten-ru) for recognizing handwritten text in the Church Slavonic, Russian and Ukrainian.

## Model Description

TrOCR (Transformer-based OCR) is a vision-to-text model using a ViT encoder and a causal language model decoder. This version is fine-tuned specifically on [Datasets Name] handwriting.

- Base model: [microsoft/trocr-base-handwritten](https://huggingface.co/microsoft/trocr-base-handwritten) via [kazars24/trocr-base-handwritten-ru](https://huggingface.co/kazars24/trocr-base-handwritten-ru) (used as an intermediate checkpoint)
- Fine-tuned on: [Datasets Name] (approx. 6800 images)
- Intended use: OCR of handwritten Church Slavonic (Cyrillic), Russian (Cyrillic), Ukrainian (Cyrillic).

## Training Data
- Train / Valid / Test split: 60% / 20% / 20%.

## Training Details

- Batch size: 16
- Epochs: 10
- Evaluation metric: CER
- Evaluation strategy: steps
- Tokenizer: kazars24/trocr-base-handwritten-ru

## Performance

| Metric | Value |
|--------|-------|
| CER (Validation) | 0.253278 |
| Qualitative results | The model performs well despite noisy labels and image distortions. |

**Note**: Some ground truth annotations were incorrect or mismatched, which affects the overall CER. The model, however, correctly predicts many visually accurate texts.

## How to Use

```python
from transformers import TrOCRProcessor, VisionEncoderDecoderModel
from PIL import Image
import requests

# Load processor and model
processor = TrOCRProcessor.from_pretrained("my-username/model-name")
model = VisionEncoderDecoderModel.from_pretrained("my-username/model-name")

# Load and prepare image
image = Image.open("your_image.jpg").convert("RGB")
pixel_values = processor(images=image, return_tensors="pt").pixel_values

# Generate prediction
generated_ids = model.generate(pixel_values)
predicted_text = processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
print(predicted_text)